function parameters = Calparameters(tree_div)
tree_divid=tree_div(:,4);
tree_divid0=unique(tree_divid);
parameters=[];
for ii=1:length(tree_divid0)
    tree_divid00=tree_divid0(ii);
    tree_index=find(tree_divid==tree_divid00);
    tree_points=tree_div(tree_index,:);
    xmax=max(tree_points(:,1));
    xmin=min(tree_points(:,1));
    ymax=max(tree_points(:,2));
    ymin=min(tree_points(:,2));
    [zmax,idzmax]=max(tree_points(:,3));
    crown=(xmax-xmin+ymax-ymin)/4;
    height=zmax;
    xtree=tree_points(idzmax,1);
    ytree=tree_points(idzmax,2);
    parameter=[xtree ytree crown height];
    parameters=[parameters; parameter];
end
parameters=[tree_divid0 parameters];
end