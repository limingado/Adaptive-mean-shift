function [out,category,hh] = meanshift(data,data2,r2,threshould,A,count,mm)
% input
% data：point cloud
% data2：CHM
% r2:Range of mean shift
% threshould：Merge threshold
% A：is the scale parameter of the crown width and local stem density
% count：termination conditions, the number of visits per point
% mm：Continue to reduce point clouds several times before switching to the next point cloud for processing（Possible noise causing sudden point cloud transformation）
% 
% out put：
% category
% hh：Record variance changes

%%
threshould2 = threshould*threshould;
[k,N] = size(data);
access_cnt = zeros(k,1);  
dir = zeros(k,N);
cluster_cnt = 1;
density_l = 0;
cnt = 2;

%% Determine the nearest point to calculate the bandwidth
xy2 = data2(1,1:3);  
data3 = data2;
data3(1,:)=[];
hxy = sqrt(min(sum((data3(:,1:2)-xy2(:,1:2)).^2,2))); %calculate the stem density
h = A*repmat(hxy,1,3)/data2(1,4);  %bandwidth change

h(3)=h(3)*500; %the bandwidth in the z direction
hh=h; %record the bandwidht of each time
[~,I] = min(sum((data-xy2).^2,2));  
center=data(I,:);%The point closest to the first point of CHM in the point cloud is the starting point for drift
num =length(data2);

while 1
    %% calculte the drift value
    for i = 1:N
        dir(:,i) = data(:,i)-center(i);
    end
    dis = sum(dir.^2,2);  
    indx = find(dis < r2^2);  
    density = length(indx);
    for i=1:N
        kk=(dir(indx,i)/h(i)).^2;  
        g=(1/(sqrt(2*pi)))*exp(-0.5*kk);   
        u=sum(data(indx,i).*g,1);  
        d=sum(g);
        M(1,i)=u/(d); 
    end
    access_cnt(indx,cluster_cnt) = access_cnt(indx,cluster_cnt) + 1; 
    

    if density_l >= density 
        m = m+1; 
        if m>mm 
        density_l = 0;
        if cluster_cnt == 1
            out(cluster_cnt,:) = center;  
        else
            dir_t = out;
            for kk = 1:cluster_cnt-1
                dir_t(kk,:) = out(kk,:)-center;   
            end
            dis_t = sum(dir_t.^2,2);
            [min_dis,min_indx] = min(dis_t);
            if min_dis < threshould2       
                access_cnt(:,min_indx)= access_cnt(:,min_indx) + access_cnt(:,cluster_cnt); 
                access_cnt(:,cluster_cnt) = 0;   
                cluster_cnt = cluster_cnt - 1;
            else
                out(cluster_cnt,:) = center;
            end
        end
        cluster_cnt = cluster_cnt +1;  
        if cnt<=num  
            xy2 = data2(cnt,1:3);
            data3 = data2;
            data3(cnt,:)=[];
            hxy = sqrt(min(sum((data3(:,1:2)-xy2(:,1:2)).^2,2)));
            h = A*repmat(hxy,1,3)/data2(cnt,4);  
            h(3)=h(3)*500;
            hh(cnt,:)=h;
            [~,I] = min(sum((data-xy2).^2,2));
            center=data(I,:);
            cnt=cnt+1;

        else
            acc_cnt_p = sum(access_cnt,2);    
            no_acc_p = find(acc_cnt_p <= count);   
            if size(no_acc_p,1) >0
                h=mean(hh,1);
                center = data(no_acc_p(1),:);  
            else
                break;
            end
        end
        if size(access_cnt,2) < cluster_cnt   
            access_cnt = [access_cnt,zeros(k,1)]; 
        end
        end
    else
        density_l = density;
        center = M; 
        m=0;
    end
end

category = zeros(k,1);
for kk = 1:k
    [~,max_indx] = max(access_cnt(kk,:));  
    category(kk) = max_indx;                     
end
