close all,clear
data=load('sapling points_denoised.txt');
figure;
pcshow(data);  

%% 获取半径
scale =10;
area =120;
[image,r,xmin,ymin,top]=tree_radius(data,scale,area) ; 
treetop_r=[top r];  %the first three colums are the local maximum values of each sample tree，and the last columu is the EquivDiameter

threshould=0.1;
radius=1.5;  
A=0.5;  % A is the scale parameter of the crown width and local stem density
count = 3;
mm = 0;

tic
[out,category,hh] = meanshift(data,treetop_r,radius,threshould,A,count,mm);
toc

%show the segmentation result
num=unique(category);
color = 0.4 + (1-0.4)*rand(length(num),3);
color2=zeros(length(category),3);
for i=1:length(num)
    num2=find(category==num(i));
    color2(category==num(i),:)=repmat(color(i,:),length(num2),1);
end
figure,pcshow(data,color2); %


num0=unique(category);
data_seg=[data category];
parameterstreeall=[];
for i=1:size(num0,1)
    idtree=num0(i);
    index0=find(category==idtree);
    tree0=data_seg(index0,:);
    parameterstree=Calparameters(tree0);
    parameterstreeall=[parameterstreeall;parameterstree];  
end


fid=fopen('pointcloud_seg.txt','wt');
[m,n]=size(data_seg);
 for i=1:1:m
      fprintf(fid,'%9.3f %10.3f %5.3f %d\n',data_seg(i,1),data_seg(i,2),data_seg(i,3),data_seg(i,4));
 end
 fclose(fid);
