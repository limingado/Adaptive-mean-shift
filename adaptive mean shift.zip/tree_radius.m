function [ image,r,xmin,ymin,top]=tree_radius(data,scale,area)

% input：
% data：point cloud；
% scale：Integrate the original data
% area：Determine whether watershed segmentation is necessary, and if it is greater than area, it is necessary to
% output：
% image：Segmented images
% r：Equivalent radius of image corresponding labels
% xmin、ymin：Scale reduction


%% Convert a 3D point cloud into an image, with the z-axis represented as the image color
xmin=min(data(:,1));
ymin=min(data(:,2));
data2 = data;
data2(:,1) = data(:,1)-xmin;
data2(:,2) = data(:,2)-ymin;

data3 = ceil(data2*scale)+1;
data3(:,3)=data2(:,3);
xmax3=max(data3(:,1));
ymax3=max(data3(:,2));

im = zeros(xmax3,ymax3);
for i=1:length(data3)
    if data3(i,3)>im(data3(i,1),data3(i,2))
        im(data3(i,1),data3(i,2))=data3(i,3);  
    end
end

%% preprocess
im2 = rescale(im,0,1);  
im2(im2>0)=1;
im2 = bwmorph (im2, 'clean');  
se = strel("disk",2) ;
J = imclose(im2,se);    
[L3,n] = bwlabel(J,8);
s= regionprops(L3, 'Centroid','Area');



%% watershed process
image = zeros(size(L3));

for i = 1:n
    L5=L3==i;
    area1 = s(i).Area;
    if area1>area  % use or not use the watershed 
        bw = 1-L5;
        D = (bwdist(bw));
        D = -D;
        D(bw==1) = -Inf;    %didn't need to process
        DL = watershed(D);  %watershed
        DL(DL==DL(1,1)) = 0;
        [L6,n2] = bwlabel(DL,8);
        
        image=image+L6;   
    else
        image =image+L5;  
    end
end
sz = size(image);
[image,n3] = bwlabel(image,8);
for i = 1:n3
    im3=image;
    im3(im3~=i)=0;
    im4=im3.*im/i;   
    [M,I] = max(im4,[],'all','linear');
    [row,col] = ind2sub(sz,I);  
    row = (row-1)/scale+xmin;   
    col = (col-1)/scale+ymin;
    top(i,1:3)=[row,col,M];     
    
end


color = 0.4 + (1-0.4)*rand(n3+1,3);
rgb = label2rgb(image,color);
figure,imshow(rgb);  

d = regionprops(image,"EquivDiameter");  
d = cat(1,d.EquivDiameter);
r = d./2;
r = r/scale;  
end

